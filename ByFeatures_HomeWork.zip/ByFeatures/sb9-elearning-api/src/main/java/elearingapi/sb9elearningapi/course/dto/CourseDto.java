package elearingapi.sb9elearningapi.course;

import elearingapi.sb9elearningapi.category.CategoryDto;
import elearingapi.sb9elearningapi.instructor.InstructorDto;
import lombok.Builder;

@Builder
public record CourseDto(
        Long id,
        String title,
        String description,
        String thumbnail,
        Boolean isFree,
        CategoryDto category,
        InstructorDto instructor
) {
}
