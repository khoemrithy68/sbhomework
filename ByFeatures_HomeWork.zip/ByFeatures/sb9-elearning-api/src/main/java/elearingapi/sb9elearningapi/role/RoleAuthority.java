package elearingapi.sb9elearningapi.role;

import jakarta.persistence.*;
import lombok.*;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
@Entity
@Table(name = "roles_authorities")
public class RoleAuthority {
    @Id @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Integer id;
    @ManyToOne
    private Role role;
    @ManyToOne
    private Authority authority;
    private Boolean isDeleted;
    private String remark;
}
