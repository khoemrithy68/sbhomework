package elearingapi.sb9elearningapi.instructor;

import lombok.Builder;

@Builder
public record InstructorDto(Integer id,
                            String familyName,
                            String givenName) {
}
