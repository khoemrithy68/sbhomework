package elearingapi.sb9elearningapi.student;

public interface StudentService {
}
