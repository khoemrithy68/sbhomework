package elearingapi.sb9elearningapi.student;

public class StudentServiceImpl {
}
