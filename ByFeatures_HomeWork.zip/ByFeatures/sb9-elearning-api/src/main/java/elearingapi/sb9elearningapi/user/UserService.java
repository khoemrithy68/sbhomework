package elearingapi.sb9elearningapi.user;

public interface UserService {

    void createNew(UserCreationDto userCreationDto);

}
