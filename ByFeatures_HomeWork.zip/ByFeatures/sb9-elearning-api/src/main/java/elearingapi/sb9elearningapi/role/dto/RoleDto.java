package elearingapi.sb9elearningapi.role;

import java.util.List;

public record RoleDto(
        String name,
        List<String> authorities
) {
}
