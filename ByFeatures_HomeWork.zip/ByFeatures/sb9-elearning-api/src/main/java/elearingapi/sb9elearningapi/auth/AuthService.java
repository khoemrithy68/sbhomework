package elearingapi.sb9elearningapi.auth;


import elearingapi.sb9elearningapi.auth.dto.VerifyDto;
import jakarta.mail.MessagingException;

import java.util.Map;

public interface AuthService {

    Map<String, Object> register(RegisterDto registerDto) throws MessagingException;

    Map<String, Object> verify(VerifyDto verifyDto);

}
