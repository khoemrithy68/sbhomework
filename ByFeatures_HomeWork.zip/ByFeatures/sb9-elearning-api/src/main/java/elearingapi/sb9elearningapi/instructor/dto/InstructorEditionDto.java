package elearingapi.sb9elearningapi.instructor;

import lombok.Builder;

@Builder
public record InstructorEditionDto(
        String familyName,
        String givenName,
        String biography
) {
}
