package elearingapi.sb9elearningapi;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Sb9ElearningApiApplication {

	public static void main(String[] args) {
		SpringApplication.run(Sb9ElearningApiApplication.class, args);
	}

}
