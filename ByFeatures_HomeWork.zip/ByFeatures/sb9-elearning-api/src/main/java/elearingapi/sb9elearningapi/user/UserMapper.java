package elearingapi.sb9elearningapi.user;

import elearingapi.sb9elearningapi.auth.RegisterDto;
import org.mapstruct.Mapper;

@Mapper(componentModel = "spring")
public interface UserMapper {

    User fromUserCreationDto(UserCreationDto userCreationDto);

    UserCreationDto mapRegisterDtoToUserCreationDto(RegisterDto registerDto);

}
