package elearingapi.sb9elearningapi.auth.dto;

import jakarta.validation.constraints.NotBlank;
import lombok.Builder;

@Builder
public record VerifyDto(
        @NotBlank
        String email,
        @NotBlank
        String verified_code
) {
}
