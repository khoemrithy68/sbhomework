package elearingapi.sb9elearningapi.security;

import elearingapi.sb9elearningapi.user.User;
import elearingapi.sb9elearningapi.user.UserRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.stereotype.Service;

@Service
@RequiredArgsConstructor
public class UserDetailsServiceImpl implements UserDetailsService {
    private final UserRepository userRepository;


    @Override
    public UserDetails loadUserByUsername(String username) throws UsernameNotFoundException {

        User user = userRepository
                .findByEmailAndIsDeletedAndAndIsVerified(username
                ,false, true)
                .orElseThrow(() -> new UsernameNotFoundException("Invalid User...!"));

        CustomUserDetails customUserDetails = new CustomUserDetails();
        customUserDetails.setUser(user);


        return customUserDetails;
    }
}
