package elearingapi.sb9elearningapi;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Sb9ElearningApiApplicationTests {

	@Test
	void contextLoads() {
	}

}
